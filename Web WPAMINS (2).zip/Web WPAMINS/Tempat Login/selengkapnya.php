<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location: login-page.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WPAMINS</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <img src="img/Logo.png" alt="">
        <h1>WPAMINS</h1>
        <ul>
            <li class="tekan"><a href='dasboard.php'><img class="tanda" src="img/dashboard.png">dasboard</li>
            <li class="tekan"><a href='artikel.php'><img class="tanda" src="img/research.png">Artikel</li>
            <li class="tekan"><a href='kontak.php'><img class="tanda" src="img/kontak.png">Kontak</li>
            <li class="tekan"><a href='tambah_aksi_full.php'><img class="tanda" src="img/ide.png">ide</li>
            <li class="log-out"><a href='logout.php'>Logout</a></li>
        </ul>
    </header>

    <main>
        <div class="tengah">
            <h1 class="ukur"><b>Menyalakan Api Dengan Menggunakan <br>Baterai</br></b></h1>
            <img class="takon" src="img/menyalakan baterai.png" alt="">
            <p>Mula-Mula Sebelum Kita Berexperimen Siapkan bahan-bahannya terlebih dahulu Seperti Baterai, 
            Kertas Alumunium, Korek Api,nah sebelum mempraktekanya hindari benda-benda yang mudah terbakar  
            seperti jangan mempraktekan ketika berada di dapur, dekat kompor gas maupun yang lainya
         </p> 

        </div>
    </main>