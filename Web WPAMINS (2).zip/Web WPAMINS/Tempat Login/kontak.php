<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('location: login-page.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WPAMINS</title>
    <title>Contact Form</title>
    <link rel="stylesheet" href="style_kontak.css">
</head>

<body>
    <header>
        <img src="img/Logo.png" alt="">
        <h1>WPAMINS</h1>
        <ul>
            <li class="tekan"><a href='dasboard.php'><img class="tanda" src="img/dashboard.png">dasboard</li>
            <li class="tekan"><a href='artikel.php'><img class="tanda" src="img/research.png">artikel</a></li>
            <li class="tekan active"><a href='kontak.php'><img class="tanda" src="img/kontak.png">kontak</a></li>
            <li class="tekan"><a href='tambah_aksi_full.php'><img class="tanda" src="img/ide.png">ide</a></li>
            <li class="log-out"><a href='index.php'><img class="tanda" src="img/logout.png">logout</a></li>
        </ul>
    </header>
    
</body>
    <div class="container">

        <div class="card-container">
            <div class="left">
                <div class="left-container">
                    <h2>Tentang Kami</h2>
                    <p>WPAMINS adalah Website yang mempelajari ilmu Sains Seperti Fisika dan Kimia.</p>
                    <br>
                    <p>Bantu Kami dengan memberi Pesan melalui Kontak ini, Buat Perkembangan Website kami kedepanya</p>
                </div>
            </div>
            <div class="right">
                <div class="right-container">
                    <form action="">
                        <h2 class="lg-view">Hubungi Kami</h2>
                        <h2 class="sm-view">Hubungi Kami</h2>
                        <input type="text" placeholder="Nama">
                        <input type="email" placeholder="Alamat Email">
                        <input type="text" placeholder="Instansi" autocomplete="off">
                        <input type="phone" placeholder="Telepone" autocomplete="off">
                        <textarea rows="10" placeholder="Pesan"></textarea>
                        <button><a href='https://mail.google.com/mail/u/0/#inbox'></a>Kirim</button>
                    </form>
                </div>
            </div>
        </div>

    </div>
</body>

</html>