<?php
    $koneksi = mysqli_connect('localhost','root', '', 'db_uas') 
    or die('koneksi gagal');
?>